Board P23/064

2 layer HASL PCB 
Board size: 173 x 137

stack100.gbt - layer 1 - Top layer data
stack100.gbl - layer 2 - Bottom layer

stencil size: 187 x 363mm
stack100_ec.gtp
