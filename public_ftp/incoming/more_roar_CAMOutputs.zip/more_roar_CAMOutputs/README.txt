more_roar_CAMOutputs.zip
 
README
 
PCB
2 layers
100 quantity
135 mm length
84 mm width
FR4 Tg 130 base material
1.6mm thickness
1.0oz copper
WHITE mask both sides
BLACK silkscreen top only 
HASL finish
No UL marking (no serial/batch number on board)
vcut (see vcut.gbr)
