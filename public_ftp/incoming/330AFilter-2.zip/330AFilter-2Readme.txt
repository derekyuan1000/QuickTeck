Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074

Email:	RitengaDes@aol.com
Order No:	
Board:	330A OP Filter Board
Rev:	2
Please Manufacture boards from the following files;
a.	330AFilter-2-Top Copper.gbr			Top side copper
b.	330AFilter-2-Top Copper(Resist).gbr		Top side solder resist
c.	330AFilter-2-Drill Data.drl			NCD Drill file

Information files
a.	330AFilter-2-Fabrication.gbr			Fabrication drawing + Dimensions
	*this file needs to be read*
b.	330AFilter-2(PCB - PLOT REPORT).txt		Aperture and Tool file
c.	330AFilter-2.gwk			 	GC Prevue files

Notes			Some screen print is outside the pcb
Board size		89.5 x 88.9mm
Board Thickness		2.4mm
			Single sided
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Level

RGDS

J.L.Wilkinson
