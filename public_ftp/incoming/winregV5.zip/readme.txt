WINREG Version 5

WINREG-0.001	Layer 0 is top silk screen
WINREG-1.001	Layer 1 is top copper
WINREG-2.001	Layer 2 is the ground plane copper
WINREG-3.001	layer 3 is board profile and dimension drawing. It is NOT a manufactured layer
WINREG-7.001	Layer 7 is the power plane copper
WINREG-8.001	Layer 8 is the bottom copper
WINREG-9.001	Layer 9 is bottom silk screen
WINREG-A.001	Layer A is the aperture table
WINREG-B.001	Layer B is the bottom soldermask
WINREG-T.001	Layer T is the top soldermask
WINREGDR.SIZ	Drill file tool table
WINREGDR.001	Drill file Excelon NC