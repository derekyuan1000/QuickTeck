P22/092
5200 Display PCB panel 6 up with v-score as detailed 1.6mm FR4, 1.0oz, Black solder mask. Silk top only, LF HASL, UL 240mm x 230mm.

Solder shim
p22-092_panel_ec.gtp - 300 x 320mm