Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074

Email:	RitengaDes@aol.com

Order No:	
Board:	3kW IPB  pcb
Rev:	1
Please Manufacture boards from the following files;
a.	3kWIPB-1 - Top Silk.gbr				Top silk screen
b.	3kWIPB-1 - Top Copper.gbr				Top side copper
c.	3kWIPB-1 - Top Copper (Resist).gbr			Top side solder resist
d.	3kWIPB-1 - Bottom Copper.gbr				Bottom side copper
e.	3kWIPB-1 - Bottom Copper (Resist).gbr		Bottom side solder resist
e	3kWIPB-1 - Drill Data - Through Hole.drl		NCD Drill file for plated holes
f.	3kWIPB-1 - Drill Data - Through Hole (Unplated).drl	NCD Drill file for un-plated holes

Information files
a.	3kWIPB-1 - Fabrication.gbr				Fabrication details
	
b.	3kWIPB-1(PCB-PLOT REPORT).txt			Aperture and Tool file
c.	3kWIPB-1.gwk			 			GC Prevue files


Board size		168.6 x 173.0mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Levelled


RGDS

J.L.Wilkinson
