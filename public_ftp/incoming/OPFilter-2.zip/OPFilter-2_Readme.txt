Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074

Email:	RitengaDes@aol.com
Order No:	
Board:	165A OP Filter Board
Rev:	2
Please Manufacture boards from the following files;
a.	OPFilter-2-Top Copper.gbr			Top side copper
b.	OPFilter-2-Top Copper(Resist).gbr		Top side solder resist
c.	OPFilter-2 - Top Silk.gbr			Top Side Silk Screen
d.	OPFilter-2 - Drill Data - Through Hole.drl	NCD Drill file
e.	OPFilter-2 - Drill Data - Through Hole.drl	NCD Drill file

Information files

a.	OPFilter-2 (PCB - PLOT REPORT).txt		Aperture and Tool file
b.	OPFilter-2.gwk				 	GC Prevue files

Board size		88.3 x 87.6mm
Board Thickness		2.4mm
			Single sided
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Level

RGDS

J.L.Wilkinson
