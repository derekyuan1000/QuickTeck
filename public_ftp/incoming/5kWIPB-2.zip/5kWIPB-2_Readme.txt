Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Fax:	01723 859303
Email:	RitengaDes@aol.com
Order No:	
Board:	5kW Input Board
Rev:	2
Date:	23 Nov 2023

Please Manufacture boards from the following files;
a.	5kWIPB-2-Top Silk.gbr				Top side ident
b.	5kWIPB-2-Top Copper.gbr				Top side copper
c.	5kWIPB-2-Top Copper(Resist).gbr			Top side solder resist
d.	5kWIPB-2-Bottom Copper.gbr			Bottom side copper
e.	5kWIPB-2-Bottom Copper(Resist).gbr		Bottom side solder resist
f.	5kWIPB-2-Drill Data.drl				NCD Drill file
g.	5kWIPB-2 - Drill Data - Through Hole (Unplated).drl	NCD Drill File unplated holes

Information files
a.	5kWIPB-2(PCB-PLOT REPORT).txt			Aperture and Tool file
b.	



Board size		168.6 x 173.0mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Level

RGDS

J.L.Wilkinson
