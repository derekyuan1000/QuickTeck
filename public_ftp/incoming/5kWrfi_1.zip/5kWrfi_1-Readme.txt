Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Fax:	01723 859303
Email:	RitengaDes@aol.com
Order No:	
Board:	5KW RFI Board
Rev:	1
Please Manufacture boards from the following files;
a.	5kWrfi_1-Top Silk.gbr			Top side ident
b.	5kWrfi_1-Bottom Copper.gbr		Bottom side copper
c.	5kWrfi_1-Bottom Copper(Resist).gbr	Bottom side solder resist
d.	5kWIPB_1-Drill Data.drl			NCD Drill file


Information files
a.	5kWIPB_1.txt				Aperture and Tool file
b.	5kWIPB_1.gwk			 	GC Prevue files


Board size		97.8 x 226.7mm
Board Thickness		1.6mm
			Single sided non-pth
Copper Thickness	0.070mm (2 oz) copper
Finish			as recommended

RGDS

J.L.Wilkinson
