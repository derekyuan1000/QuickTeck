Board P22/077b

4 layer ENIG PCB 
Layer stack ( 150 x 125mm )

5200mk2_ec.gtl - layer 1 - Top layer data
5200mk2_ec.gp1 - layer 2 inverted
5200mk2_ec.g1  - layer 3
5200mk2_ec.gbl - layer 4 - Bottom layer

