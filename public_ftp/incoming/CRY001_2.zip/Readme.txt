Company Name:- Crystal & Son Ltd   Contact:- Mike Wright
                                   Tel +44 191 2624056
mike@crystalandson.co.uk

Date of this iss 10/01/23

CONTAINS THE FOLLOWING GERBER DATA FILES AND N/C DRILL DATA
PRODUCED BY PADS/WORK Ver 7.0

PCB Reference  CRY001 Iss 2.0

2 Sided PTH  PCB Size 62.8 mm x 44.2 mm

Photoplots supplied for:

Artwork Level 1 Component side
Artwork Level 2 Solder Side
Solder Mask  BOTH SIDES


NC Drill Data

File info:
ART01    PHO  ARTWORK SIDE 1 COMPONENT SIDE
ART02    PHO  ARTWORK SIDE 2 SOLDER SIDE
SMK02    PHO  SOLDER MASK BOTH SIDES

ART01    REP APERTURE REPORT FILE
ART02    REP		"
SMK02    REP     	"	BOTH SIDES

DRL00    DRL  NC DRIL INFO
DRL00    LST
DRL00    REP


