Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Fax:	01723 859303
Email:	RitengaDes@aol.com
Order No:	
Board:	5kW Control Board
Rev:	1
Date:	23 Aug 2017

Please Manufacture boards from the following files;
a.	5kWControl_1 - Top Silk.gbr				Top side ident
b.	5kWControl_1 - Top Copper.gbr				Top side copper
c.	5kWControl_1 - Top Copper(Resist).gbr			Top side solder resist
d.	5kWControl_1 - Bottom Copper.gbr			Bottom side copper
e.	5kWControl_1 - Bottom Copper(Resist).gbr		Bottom side solder resist
f.	5kWControl_1 - Drill Data.drl				NCD Drill file
g.	5kWControl_1 - Drill Data - Through Hole (Unplated).drl	NCD Drill File unplated holes

Information files
a.	5kWControl_1(PCB-PLOT REPORT).txt			Aperture and Tool file
b.	5kWControl_1.gwk			 		GC Prevue files



Board size		168.6 x 68.6mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Level

RGDS

J.L.Wilkinson
