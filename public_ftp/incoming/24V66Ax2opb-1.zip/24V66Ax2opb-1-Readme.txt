Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074

Email:	RitengaDes@aol.com

Order No:	
Board:	24V 66A x 2 OPB pcb
Rev:	1
Date:	16 Aug 2017

Please Manufacture boards from the following files;
a.	24V66Ax2opb-1 - Top Silk.gbr				Top silk screen
b.	24V66Ax2opb-1 - Top Copper.gbr				Top side copper
c.	24V66Ax2opb-1 - Top Copper (Resist).gbr			Top side solder resist
d.	24V66Ax2opb-1 - Bottom Copper.gbr			Bottom side copper
e.	24V66Ax2opb-1 - Bottom Copper (Resist).gbr		Bottom side solder resist
e	24V66Ax2opb-1 - Drill Data - Through Hole.drl		NCD Drill file for plated holes
f.	24V66Ax2opb-1 - Drill Data - Through Hole (Unplated).drl	NCD Drill file for un-plated holes

Information files
a.	24V66Ax2opb-1 - Fabrication.gbr				Fabrication details
	
b.	24V66Ax2opb-1(PCB-PLOT REPORT).txt			Aperture and Tool file
c.	24V66Ax2opb-1.gwk			 		GC Prevue files


Board size		130.5 x 302.3mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.070mm (2 oz) copper
Finish			Hot Air Solder Levelled


RGDS

J.L.Wilkinson
