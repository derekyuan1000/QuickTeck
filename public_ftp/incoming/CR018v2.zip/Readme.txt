Company Name Crystal & Son Ltd   Contact:- Mike Wright
                                   Tel +44 191 2624056
mike@crystalandson.co.uk

Date of this issue 9/05/23

CONTAINS THE FOLLOWING GERBER DATA FILES AND N/C DRILL DATA
PRODUCED BY PADS/WORK Ver 7.0

PCB Reference  CR-018 Ver 2
Two sided PCB Size 188.5 mm x 62 mm

Photoplots supplied for:

Artwork Side1 & Side 2
Solder Mask
Silk Screen - Legend Side 1 & Side 2
NC Drill Data

Gerber File info:
ART01   PHO  	Artwork side 1
ART02	PHO	Artwork side 2
SM02	PHO	Solder Mask - Both sides
SS01	PHO	SilkScreen side 1
SS02	PHO	SlikScreen side 2
 
Aperture Report Files
ART01  	REP 	 Side 1
ART02  	REP    	   "  2
SM02	REP	 Solder Mask 
SS01	REP	 SilkScreen side 1
SS02	REP	 SilkScreen side 2
  
DRL00    DRL  NC DRIL INFO
DRL00    LST
DRL00    REP


