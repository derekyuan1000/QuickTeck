Pleas find attached files for the order.

I have include 3 pdf files showning how it should look if you have any problems please contact me.
terry660@hotmail.co.uk

The Board size is Length 100mm X Width 95 mm the only constraint we have is the Width can be no bigger than 97mm.

Regards

George Hughes