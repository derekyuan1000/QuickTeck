KENTON ELECTRONICS LTD -

lndx1v00 (line driver pro - issue 1v00) - 28/02/2023

ANY PROBLEMS PLEASE CONTACT - JOHN PRICE on 020-8544-9090 or 07802-667105

FILES FOR THIS DESIGN ARE AS FOLLOWS :-

----------------------------------------------------------------------------

lndx1v00 top layer.ger           =  TOP LAYER
lndx1v00 bottom layer.ger        =  BOTTOM LAYER
lndx1v00 solder mask TL.ger      =  SOLDER MASK FOR TOP LAYER
lndx1v00 solder mask BL.ger      =  SOLDER MASK FOR BOTTOM LAYER
lndx1v00 solder paste.ger        =  SOLDER PASTE FOR TOP LAYER

lndx1v00 drill-tool imperial.txt =  EXCELLON DRILL & TOOL FILE IMPERIAL
lndx1v00 drill-tool metric.txt   =  EXCELLON DRILL & TOOL FILE METRIC

----------------------------------------------------------------------------

1.6mm
1oz
Double Sided PTH
Solder mask top & bottom
No Ident
Electroless Gold finish
RoHS3 compliant

Please note: 

The crop marks are 10 thou wide and are centred exactly on the true edges of the board hence:-
the centres of the crop marks are the true edges of the board.

John K Price
Kenton Electronics Limited
Unit 13, First Quarter
Blenheim Road
Epsom
KT19 9QN

Tel: 020-8544-9090 direct line
Mob: 07802-667105
E:   jkp@kenton.co.uk
