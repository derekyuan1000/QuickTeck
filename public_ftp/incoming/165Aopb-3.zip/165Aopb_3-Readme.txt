Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Mob:	07946 375817
Email:	RitengaDes@aol.com
Order No:	
Board:	165A Output Board
Rev:	3
Please Manufacture boards from the following files;
a.	165Aopb_3-Top Silk.gbr			Silk Screen
b.	165Aopb_3-Top Copper.gbr		Top side copper
c.	165Aopb_3-Top Copper(Resist).gbr	Top side solder resist
d.	165Aopb_3-Bottom Copper.gbr		Bottom side copper
e.	165Aopb_3-Bottom Copper(Resist).gbr	Bottom side solder resist
f.	165Aopb_3-Drill Data.drl		NCD Drill file for plated holes
g.	165Aopb_3-Drill Data(unplated).drl	NCD Drill file for un-plated holes

Information files
a.	165Aopb_3-Fabrication.gbr		Fabrication drawing
	*this file needs to be read*
b.	165Aopb_3 (PCB-PLOT REPORT).txt		Aperture and Tool file
c.	

Board size		130.5 x 226.7mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.07mm (2 oz) copper
Finish			Lead Free Hot Air Solder Levelled (RoHS compliant)


RGDS

J.L.Wilkinson
