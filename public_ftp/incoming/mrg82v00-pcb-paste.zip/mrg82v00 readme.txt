KENTON ELECTRONICS LTD. -

MRG82v00 - (Merge8 - issue 2v00) - 21/03/2024

ANY PROBLEMS PLEASE CONTACT - JOHN PRICE on 020-8544-9090 or 07802-667105

FILES FOR THIS DESIGN ARE AS FOLLOWS :-

----------------------------------------------------------------------------

mrg82v00 top layer.gbr           =  TOP LAYER
mrg82v00 bottom layer.gbr        =  BOTTOM LAYER
mrg82v00 solder mask TL.gbr      =  SOLDER MASK FOR TOP LAYER
mrg82v00 solder mask BL.gbr      =  SOLDER MASK FOR BOTTOM LAYER

mrg82v00 drill-tool imperial.txt =  EXCELLON DRILL & TOOL FILE IMPERIAL
mrg82v00 drill-tool metric.txt   =  EXCELLON DRILL & TOOL FILE METRIC


----------------------------------------------------------------------------

Individual boards - no stepping

1.6mm
1oz
Double Sided PTH
Solder mask (Top & Bottom)
No Ident
Gold finish
RoHS3 compliant and UL
                                        
Please note: 

The crop marks are 10 thou wide and are centred exactly on the true edges of the board hence:-
the centres of the crop marks are the true edges of the board.

----------------------------------------------------------------------------

The manufactured boards must be RoHS3 compliant & UL

Thanks  - John K Price

Kenton Electronics Limited
Unit 3, Epsom Downs Metro Centre
Waterfield
Tadworth
Surrey
KT20 5LR

Tel: 020-8544-9090 direct line
Mob: 07802-667105
E:   jkp@kenton.co.uk


