Company Name  Crystal & Son Ltd    Contact:- Mike Wright
email mike@crystalandson.co.uk     Tel 0191 262 4056
Date of this issue 12/06/23

CONTAINS THE FOLLOWING GERBER DATA FILES AND N/C DRILL DATA
PRODUCED BY PADS/WORK Ver 7.0

PCB Reference  CR001 7SEG Ver 1.2

Two Sided conventional PCB Size 244 mm x 190.5 mm

Photoplots supplied for:

Artwork Level 1
Artwork Level 2
Solder Mask  - Black Ink Both sides
Legend Level 2


ART01    PHO  ARTWORK SIDE 1
ART02    PHO  ARTWORK SIDE 2
SM0128   PHO  SOLDER MASK SIDE 1
SM0228   PHO  SOLDER MASK SIDE 2
SSB0229  PHO  LEGEND SIDE 2

ART01    REP  APERTURE REPORT FILE
ART02    REP           "
SM0128   REP           "
SM0228   REP           "
SSB0229  REP           "

DRL00    DRL  NC DRIL INFO
DRL00    LST
DRL00    REP


