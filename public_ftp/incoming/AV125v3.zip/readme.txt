Readme File for Printed Circuit Board 'AV125-A1L '  'Serial and I/O USB Adapter V3'

Board Specification
Size           39 x 24mm
Material       FR4
No of Layers   4
Thickness      1.6
Finish         HASL
Copper Weight  1.0oz							

Special Requirements
We require a GREEN RESIST top & bottom.
White Silk.

The design does not contain Blind Vias			
The design does not contain Buried Vias			
The design does not contain holes smaller than 14 thou

The design conforms to the following design rules
Minimum track thickness 10 thou 
Minimum track-track clearance 10 thou 

Layer Description

Top Silk Screen Overlay		TopSilk.SPL
Top Solder Mask			TopRest.SPL
Top Copper			TopElec.SPL
GND				GND.SPL
Inner1				Inner1.SPL
Bottom Copper			BotElec.SPL
Bottom Solder Mask		BotRest.SPL
Bottom Silk Screen Overlay	BotSilk.SPL
Drill Drawing  			Drill.spl
NC Drill File			NCDP.spl


Drill No.  Tool No.      Size     Count   File Name
------------------------------------------------------------
         0         1        15        65
         1         2        20         1
         2         3        24        10
         3         4        36         6
------------------------------------------------------------
                         TOTAL        82

Drill Report
------------
 
   Size    Letter     Count
      ----    ------     -----
        15         A        65
        20         B         1
        24         C        10
        36         D         6



Conact Information

Invoice Address
Name           Tom White
Company        Advanced Vision Technology Ltd
Address        Thames House, Mere Park
City           Marlow
County         Buckinghamshire
PostCode       SL7 1PB
Email          tom@avtechuk.com
Phone          +44(0)1628 473749

Delivery Address
Name           Tom White
Company        Advanced Vision Technology Ltd
Address        Thames House, Mere Park
City           Marlow
County         Buckinghamshire
PostCode       SL7 1PB
Email          tom@avtechuk.com
Phone          +44(0)1628 473749

