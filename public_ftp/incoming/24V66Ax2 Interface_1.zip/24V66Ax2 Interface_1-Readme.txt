Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Fax:	01723 859303
Email:	RitengaDes@aol.com
Order No:	
Board:	24V66Ax2 Interface Board
Rev:	1
Date:	25 July 2012

Please Manufacture boards from the following files;
a.	24V66Ax2 Interface_1-Top Silk.gbr				Top side ident
b.	24V66Ax2 Interface_1 - Top Copper.gbr				Top side copper
c.	24V66Ax2 Interface_1-Top Copper(Resist).gbr			Top side solder resist
d.	24V66Ax2 Interface_1-Bottom Copper.gbr				Bottom side copper
e.	24V66Ax2 Interface_1-Bottom Copper(Resist).gbr			Bottom side solder resist
f.	24V66Ax2 Interface_1-Drill Data.drl				NCD Drill file
g.	24V66Ax2 Interface_1 - Drill Data - Through Hole (Unplated).drl	NCD Drill File unplated holes

Information files
a.	24V66Ax2 Interface_1(PCB-PLOT REPORT).txt			Aperture and Tool file
b.	24V66Ax2 Interface_1.gwk			 		GC Prevue files



Board size		99.1 x 144.8mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Level

RGDS

J.L.Wilkinson
