Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Fax:	01723 859303
Email:	RitengaDes@aol.com
Order No:	
Board:	pwm Control Board
Rev:	1
Date:	05 June 2017

Please Manufacture boards from the following files;
a.	pwmControl_1 - Top Silk.gbr				Top side ident
b.	pwmControl_1 - Top Copper.gbr				Top side copper
c.	pwmControl_1 - Top Copper(Resist).gbr			Top side solder resist
d.	pwmControl_1 - Bottom Copper.gbr			Bottom side copper
e.	pwmControl_1 - Bottom Copper(Resist).gbr		Bottom side solder resist
f.	pwmControl_1 - Drill Data.drl				NCD Drill file
g.	pwmControl_1 - Drill Data - Through Hole (Unplated).drl	NCD Drill File unplated holes

Information files
a.	pwmControl_1(PCB-PLOT REPORT).txt			Aperture and Tool file
b.	pwmControl_1.gwk			 		GC Prevue files



Board size		73.7 x 41.6mm
Board Thickness		1.6mm
			Double sided pth
Copper Thickness	0.035mm (1 oz) copper
Finish			Hot Air Solder Level

RGDS

J.L.Wilkinson
