
100x80mm 1.6 FR4 2 layers 1oz

PTH only, no NPTH or SMD (top and bottom mask are same)

stackup:
F_Silkscreen
F_Mask
F_Cu
B_Cu
B_Mask