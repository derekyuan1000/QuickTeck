Attn:	
From:	Ritenga Design Ltd
	Scarborough
Tel:	01723 859074
Mob:	07946 375817
Email:	RitengaDes@aol.com
Order No:	
Board:	3KW RFI Board
Rev:	1
Please Manufacture boards from the following files;
a.	3kWRFI_1-Top Silk.gbr				Top side ident
b.	3kWRFI_1-Bottom Copper.gbr			Bottom side copper
c.	3kWRFI_1-Bottom Copper(Resist).gbr		Bottom side solder resist
d.	3kWRFI-1-Drill Data - [Through Hole]		NCD Drill file
e.	3kWRFI-1-Drill Data - [Through Hole] (Unplated)	NCD Drill file


Information files;
a.	3kWRFI-1 (PCB - PLOT REPORT).txt		Aperture and Tool file
b.	

Note			There are 3 pads which are outside of the pcb outline
Board size		97.8 x 226.7mm
Board Thickness		1.6mm
			Single sided non-pth
Copper Thickness	0.035mm (1 oz) copper
Finish			as recommended

RGDS

J.L.Wilkinson
