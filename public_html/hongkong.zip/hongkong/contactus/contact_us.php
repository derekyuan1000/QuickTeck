<html>
<head>
<title>Quank</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">
.style1 {
text-align:center;
}
</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><table border="0" cellpadding="0" cellspacing="0" width="644">
		  <tr>
		   <td><table border="0" cellpadding="0" cellspacing="0" width="644">
			  <tr>
			   <td><img name="layout_r1_c1" src="images/layout_r1_c1.jpg" width="12" height="24" border="0" alt=""></td>
			   <td><table border="0" cellpadding="0" cellspacing="0" width="442">
				  <tr>
				   <td><img name="layout_r1_c2" src="images/layout_r1_c2.jpg" width="442" height="4" border="0" alt=""></td>
				  </tr>
				  <tr>
				            <td height="20" background="images/layout_r2_c2.jpg"> 
                              <b> 
                              <a href="HTTP://"><font color="#CCCCCC" size="1">HOME</font></a><font size="1" color="#CCCCCC">&nbsp; |&nbsp;
                              </font> <a href="http://">
                              <font color="#CCCCCC" size="1">ABOUT 
                              US</font></a><font color="#CCCCCC" size="1">&nbsp; |&nbsp;
                              </font> <a href="http://">
                              <font color="#CCCCCC" size="1">CONTACT US</font></a><font color="#CCCCCC" size="1">&nbsp; |&nbsp;
                              </font> <a href="http://">
                              <font color="#CCCCCC" size="1">PRODUCTS 
                              PAGE</font></a><font color="#CCCCCC" size="1">&nbsp; |&nbsp;
                              </font> <a href="http://">
                              <font color="#CCCCCC" size="1">MORE LINKS</font></a></b></td>
				  </tr>
				</table></td>
			   <td><img name="layout_r1_c6" src="images/layout_r1_c6.jpg" width="190" height="24" border="0" alt=""></td>
			  </tr>
			</table></td>
		  </tr>
		  <tr>
		   <td><table border="0" cellpadding="0" cellspacing="0" width="644">
			  <tr>
			   <td><img name="layout_r3_c1" src="images/layout_r3_c1.jpg" width="86" height="243" border="0" alt=""></td>
			   <td height="243" width="308" background="images/company_name.jpg">
			   <table border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
            <div align="center">
              <font color="#666666"><b><font size="5">
				Quark Electronic</font></b></font></div>
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center">
              <font size="4" color="#666666">
				One stop electronic solution
			  </font>
			 </div>
          </td>
        </tr>
        <tr> 
          <td style="height: 19px"></td>
        </tr>
      </table>
			   
			   
			   </td>
			   <td><img name="layout_r3_c5" src="images/layout_r3_c5.jpg" width="88" height="243" border="0" alt=""></td>
			   <td><table border="0" cellpadding="0" cellspacing="0" width="162">
				  <tr>
				   <td><img name="layout_r3_c8" src="images/layout_r3_c8.jpg" width="162" height="147" border="0" alt=""></td>
				  </tr>
				  <tr>
				   <td><img name="layout_r5_c8" src="images/layout_r5_c8.jpg" width="162" height="96" border="0" alt=""></td>
				  </tr>
				</table></td>
			  </tr>
			</table></td>
		  </tr>
		</table></td>
	   <td><table border="0" cellpadding="0" cellspacing="0" width="116">
		  <tr>
		   <td><img name="layout_r1_c9" src="images/layout_r1_c9.jpg" width="116" height="171" border="0" alt=""></td>
		  </tr>
		  <tr>
		   <td><img name="layout_r5_c9" src="images/layout_r5_c9.jpg" width="116" height="96" border="0" alt=""></td>
		  </tr>
		</table></td>
	  </tr>
	</table></td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	      <td width="100%" valign="top"><img name="layout_r9_c1" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt="">
	        <table width="100%" border="0" cellspacing="4" cellpadding="4">
	          <tr> 
	            <td><span class="style1"><br>Hong Kong address: <br><br>
	              Quark (Hong kong) Electronic co.,<br>
	              Flat 93G-99H G/FLOOR,Hung Fat<br>
	              93-99 Kau Yuk Road, Yuen Long,<br>
	              Hong Kong </span><br>
	                
                </td>
              </tr>
            </table></td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
    <tr>
    <td height="57" valign="middle" background="images/layout_r10_c1.jpg"><table width="100%" border="0" cellspacing="4" cellpadding="4">
        <tr>
          <td><font size="1"><strong>COPYRIGHT (C) 2002-2011, Quark Electronic (Hong Kong) Ltd.</strong></font><br>
            <strong><font size="1">HOME | ABOUT US | CONTACT US | PRODUCTS PAGE 
          | NEWS | MORE LINKS...</font></strong></td>
        </tr>
      </table></td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>