<table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><table border="0" cellpadding="0" cellspacing="0" width="644">
		  <tr>
		   <td><table border="0" cellpadding="0" cellspacing="0" width="644">
			  <tr>
			   <td><img name="layout_r1_c1" src="images/layout_r1_c1.jpg" width="12" height="24" border="0" alt=""></td>
			   <td><table border="0" cellpadding="0" cellspacing="0" width="442">
				  <tr>
				   <td><img name="layout_r1_c2" src="images/layout_r1_c2.jpg" width="442" height="4" border="0" alt=""></td>
				  </tr>
				  <tr>
				    <td height="20" background="images/layout_r2_c2.jpg"> 
		<div id="box">
		<div id="nav">  

    <ul>  

    <li class="menu2" onMouseOver="this.className='menu1'" onMouseOut="this.className='menu2'"><a href="index.php">Home</a><div class="list">
	 <br />  
    </div>  </li>  

    <li class="menu2" onMouseOver="this.className='menu1'" onMouseOut="this.className='menu2'"><a href="about_us.php">About us</a><div class="list">
	 <br />  
    </div> </li>  

    <li class="menu2" onMouseOver="this.className='menu1'" onMouseOut="this.className='menu2'"><a href="index.php">Services</a><div class="list">  

        <a href="inspection.php">Product inspection</a><br />  
        <a href="labtest.php">Laboratory testing</a><br />  
        <a href="audit.php">Factory audit</a><br />  
        <a href="certificate.php">Certificate service</a><br /> 
    </div>  
    </li>  

<li class="menu2" onMouseOver="this.className='menu1'" onMouseOut="this.className='menu2'">
<a href="contact_us.php">Contact us</a><div class="list">  
    <br />  
    </div>  
    </li>  
    </ul>  
</div>	
</div>			    </td>
				  </tr>
				  
				</table></td>
			   <td><img name="layout_r1_c6" src="images/layout_r1_c6.jpg" width="190" height="24" border="0" alt="" /></td>
			  </tr>
			</table></td>
		  </tr>
		  <tr>
		   <td><table border="0" cellpadding="0" cellspacing="0" width="644">
			  <tr>
			   <td height="243" width="482" background="images/company_name.jpg">
			   <table border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
            <div align="center">
              <font color="#666666"><b><font size="6">
				Quark Technologies</font></b></font></div>
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center">
              <font size="4" color="#666666" style="font-style:italic">
				One Stop Production Partner</font></div>
          </td>
        </tr>
        <tr> 
          <td style="height: 19px"></td>
        </tr>
      </table>
	   </td>
			   <td><table border="0" cellpadding="0" cellspacing="0" width="162">
				  <tr>
				   <td><img name="layout_r3_c8" src="images/layout_r3_c8.jpg" width="162" height="147" border="0" alt=""></td>
				  </tr>
				  <tr>
				   <td><img name="layout_r5_c8" src="images/layout_r5_c8.jpg" width="162" height="96" border="0" alt=""></td>
				  </tr>
				</table></td>
			  </tr>
			</table></td>
		  </tr>
		</table></td>
	   <td><table border="0" cellpadding="0" cellspacing="0" width="116">
		  <tr>

<td height="171" width="116" background="images/layout_r1_c9.jpg">
           <table border="0" cellspacing="0" cellpadding="0" align="center">
                 <tr>
                   <td>
				   <a href="http://translate.google.com/translate?hl=zh-CN&sl=en&tl=pt&u=http%3A%2F%2Fwww.quick-teck.co.uk%2F" target="_blank">
				   <img name="France" src="images/france.gif" width="22" border="0" alt=""></a> &nbsp; </td>
				   <td>
				   <a href="http://translate.google.com/translate?hl=zh-CN&sl=en&tl=pt&u=http%3A%2F%2Fwww.quick-teck.co.uk%2F" target="_blank">
				   <img name="Germany" src="images/germany.gif" width="22" border="0" alt=""></a> &nbsp;</td>
				   <td>
				   <a href="http://translate.google.com/translate?hl=zh-CN&sl=en&tl=pt&u=http%3A%2F%2Fwww.quick-teck.co.uk%2F" target="_blank">
				   <img name="Spain" src="images/spain.gif" width="22" border="0" alt=""></a> &nbsp;</td>
				 </tr>
			 <tr><td height="140"><br/></td></tr>
            </table></td>

		  </tr>
		  <tr>
		   <td><img name="layout_r5_c9" src="images/layout_r5_c9.jpg" width="116" height="96" border="0" alt=""></td>
		  </tr>
		</table></td>
	  </tr>
	</table>