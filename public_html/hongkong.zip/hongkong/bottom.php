  <tr>
    <td height="57" valign="middle" background="images/layout_r10_c1.jpg"><table width="100%" border="0" cellspacing="4" cellpadding="4">
        <tr>
          <td align="center"><font size="1"><strong>COPYRIGHT (C) 2002-2011, Quark Electronic (Hong Kong) Ltd.</strong></font><br>
            <strong><font size="1"> <a href="index.php"><font color="#000000" size="1">HOME</font></a> | <a href="about_us.php"><font color="#000000" size="1">ABOUT US</font></a> | <a href="index.php"><font color="#000000" size="1">SERVICES</font></a> | <a href="contact_us.php"><font color="#000000" size="1">CONTACT US</font></a> </strong></td>
        </tr>
      </table></td>
  </tr>