<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">

.style1 {
				text-align: center;
				font-size: x-large;
				color: #FFFFFF;
				 font-weight:bold;

}
.style2 {
 text-align:center;
 font-size:20px;
	border: 3px solid #FFFFCC;
}
.style3 {
				font-size:15px;
				text-align: left;
}
.style4 {
				
				font-size:20px;
				font-family: Verdana;
				font-weight: bold;
				color: #FF6600;
}

</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
  <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
<tr>
  <td  colspan="2" bgcolor="FFA500" class="style1" width="100%" height="40">
<strong>Compliance Certificate</strong></td>
</tr>
 <tr>
 <td height="220" width="372" style="line-height:25px">
 <span class="style15"><font face="Verdana" size="medium">Compliance certificate requirements</font></span>
 <p class="MsoNormal">
<font face="verdana, geneva" size="small" class="Apple-style-span">
<img alt="Quick-teck,PCB manufacture" src="/images/mark1.gif" width="12" height="12" > Unique for each product<br><br>
<img alt="Quick-teck,UK PCB manufacture" src="/images/mark1.gif" width="12" height="12" > Unique for each country<br><br>
<img alt="Quick-teck,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Changing continually<br><br>

</font></p>

 
</td><td width="388" class="style31">
<img alt="Quick-teck PCB manufacture,component sourcing" src="images/certificatepage1.jpg" width="388" height="309" />

</td>
</tr>
<tr><td  colspan="2" width="100%" height="40">
<span class="style3"><br>
Each country has vastly different compliance requirements which can change at any time. And every unique product has varying requirements as well. Failure to comply in each country can result in costly fines or long delays. Compliance is a key objective if your company is regulated, producing consumer products or being held to a high standard of excellence by your customers. Qualification provides documented evidence that equipment is properly installed, configured, calibrated and suitable for use in your application.<br><br>
Quark Technologies experts can show you exactly which requirements your particular product must meet, and what specific testing and documentation is required to insure compliance. We also deliver a milestone and timeline plan to help you meet your scheduled product launch.<br><br>
In addition, we offers turnkey testing and certification management services to meet all of your global certification needs in a timely and cost effective manner.<br><br>
Our compliance certificate service includes the following deliverables:<br><br>

<br>

&bull; A customized, detailed Test Plan <br>
&bull; A comprehensive list of required standards in each country for each particular product and accessory<br>
&bull; The description of each standard and all necessary tests<br>
&bull; Percept's analysis of each specific product based on the information provided<br>
&bull; An accurate, detailed price quotation for testing the product to applicable standards<br>
&bull; A timeline that details how long each test will take, and the expected completion of the project<br>
&bull; A quote for comprehensive turnkey testing and certification service <br><br>
</span>
</td></tr>

	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>

 <?php include("bottom.php") ?>

  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>