<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">
.style1 {
				text-align: center;
				font-size: x-large;
				color: #FFFFFF;
				 font-weight:bold;

}

.style2 {
 text-align:center;
 font-size:20px;
	border: 3px solid #FFFFCC;
}
.style3 {
				font-size:15px;
				text-align: left;
}

</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
  <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	      <td width="100%" valign="top"><img name="layout_r9_c1" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt="">
	        <table width="100%" border="0" cellspacing="4" cellpadding="4">
	         <tr>
  <td  colspan="2" bgcolor="FFA500" class="style1" width="100%" height="40">
<strong>About us</strong></td>
</tr>
<tr><td  colspan="2" width="100%" height="40">
<span class="style3"><br>
Quark Technologies started as a leading professional production consulting company specializing in lab testing, compliance certification, production inspection, factory audit, cost analysis, and business intelligence solutions to management. We offer international buyers a basket of integrated services to bring more confidence, security and knowledge in ordering from Far East factories. Through every step of the process, Quark has the expertise and professionalism to prevent surprises.<br><br>
Incorporated in Hong Kong in 2002, Quark consistently delivers significant market advantage and improved efficiency to a variety of leading businesses and organizations across North America and European countries. Together with our partners, we serve personal electronics, the telecom, broadband, LED lighting, building security, medical equipment, oil industrial markets, etc,. We also serve many of the top global electronics giants, including Cisco, Motorola, Pure, NXP, Lego, Brother, Sony, Hewlitt-Packard, and Toshiba.<br><br>
At Quark Technologies, we measure our success by our commitment to our customers. As such, we continue to strive for zero defects, on-time delivery, and effective, courteous support that not only meets, but exceeds our customers� expectations.<br><br>

</span></td></tr>
            </table></td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>

 <?php include("bottom.php") ?>

  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>