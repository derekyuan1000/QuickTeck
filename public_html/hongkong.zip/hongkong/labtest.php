<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">

.style1 {
				text-align: center;
				font-size: x-large;
				color: #FFFFFF;
				 font-weight:bold;

}
.style2 {
 text-align:center;
 font-size:20px;
	border: 3px solid #FFFFCC;
}
.style3 {
				font-size:15px;
				text-align: left;
}
</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
  <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
<tr>
  <td  colspan="2" bgcolor="FFA500" class="style1" width="100%" height="40">
<strong>Laboratory Testing</strong></td>
</tr>
 <tr>
 <td height="220" width="413" style="line-height:25px">
 <span class="style15"><font face="Verdana" size="medium">The range of tests we offer include:</font></span>			
<p class="MsoNormal">
<font face="verdana, geneva" size="small" class="Apple-style-span">
<img alt="Quark,PCB manufacture" src="/images/mark1.gif" width="12" height="12" > RoHS<br>
<img alt="Quark,UK PCB manufacture" src="/images/mark1.gif" width="12" height="12" > Electric Component Testing<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > EMC Testing<br>
<img alt="Quark,PCB manufacture,UK" src="/images/mark1.gif" width="12" height="12" > Functional Testing<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Safety  Analysis<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Reliability testing<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Fatigue testing<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Wireless and RF performance<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Cost  Analysis<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Benchmarking
</font></p>

 
</td><td width="347" class="style31">
<img alt="Quark PCB manufacture,component sourcing" src="images/testpage1.jpg" width="347" height="346" />

</td>
</tr>
<tr><td  colspan="2" width="100%" height="40">
<span class="style3">With facility located in Guangzhou, China, Quark Technologies provides a quick, and cost efficient route for product approvals with its affiliated testing laboratory. Quark Technologies  is supported by the resources of the entire organization and is capable of evaluating almost any electronics product for performance, safety, and quality. Our pre-compliance testing service provides the same standard and procedure as the international compliance labs, but we are more flexible and easy to accommodate with your schedule. For organizations with global markets and multiple product categories, Quark can provide one-stop solution for International Markets.<br><br>

Our EMC testing service offers advice on the legal requirements of CE marking for EMC, and provides a complete technical solution for your EMC, Radio and Safety testing from design to technical troubleshooting through to production, as well as on the spot advice and solutions for compliance. Our expertise extends from consumer product, to communication, healthcare, automotive, electronic toy, recreational, and industrial products. We ensure that your products and services meet the requirements for quality, safety and performance through our lab testing services.
</span></td></tr>

	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>

 <?php include("bottom.php") ?>

  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>