<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">
.style1 {
 text-align:center;
 font-size:20px
}
.style2 {
	border: 3px solid #FFFFCC;
}

</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
  <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	      <td width="100%" valign="top"><img name="layout_r9_c1" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt="">
	        <table width="100%" border="0" cellspacing="4" cellpadding="4">
	          <tr> 
	            <td><table>
				<tr>
				 <td width="380" class="style2"><span class="style1"><br>
				 Hong Kong address:<br><br>
	              Quark (Hong kong) Electronic co.,<br>
	              Flat 93G-99H G/FLOOR,Hung Fat<br>
	              93-99 Kau Yuk Road, Yuen Long,<br>
	              Hong Kong </span>
				  </td>
				 <td width="380" class="style2"><span class="style1"><br>
				 China (Mainland) address:<br><br>
				
	              Quark (China) Electronic<br>
	              No. 492 Daguan Road M.<br>
	              Dongpu Town, Tianhe District,<br>
	              Guangzhou,
				  P.R.C.</span></td>
				</tr>
				</table>
	                
                </td>
              </tr>
            </table></td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>

 <?php include("bottom.php") ?>

  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>