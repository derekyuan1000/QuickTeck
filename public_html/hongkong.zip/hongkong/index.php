

<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">
.style1 {
				color: #FF6600;
				font-weight:bold;
				font-size:20px
}
.style2 {
				color:#000000;
				font-weight:normal

}
.style3 {
				font-size:15px;
				text-align: left;
}
</style>

<body bgcolor="#ffffff" topmargin="0" onLoad="">
<div class="page">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
   <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	      <td width="100%" valign="top"><img name="layout_r9_c1" src="images/layout_r9_c1.jpg" width="454" height="18" border="0" alt="">
	        <table width="100%" border="0" cellspacing="4" cellpadding="4">
	          <tr> 
	            <td><span class="style3"><br>Quark Technologies started as a leading professional production consulting company specializing in lab testing, compliance certification, production inspection, factory audit, cost analysis, and business intelligence solutions to management. We offer international buyers a basket of integrated services to bring more confidence, security and knowledge in ordering from Far East factories. Through every step of the process, Quark has the expertise and professionalism to prevent surprises.</span></td>
              </tr>
            </table></td><td valign="top" background="images/layout_r8_c6.jpg"><table border="0" cellpadding="0" cellspacing="0" width="306">
		  <tr>
		   <td><img name="layout_r6_c6" src="images/layout_r6_c6.jpg" width="306" height="29" border="0" alt=""></td>
		  </tr>
		  <tr>
		   <td><table border="0" cellpadding="0" cellspacing="0" width="306">
			  <tr>
			   <td><img name="layout_r7_c6" src="images/layout_r7_c6.jpg" width="21" height="102" border="0" alt=""></td>
			          <td width="100%" valign="top" background="images/layout_r7_c7.jpg"><span class="style3"><br>We have a team of well-experienced professionals and technicians of testing, inspection and certification, and have a high efficiency management system. Through the good cooperation of the whole staff, our prompt operation cycle can help you to insure the shipment on schedule.</span><a href="why_us.php"><span class="style2">  More...</span></a></td>
			          <td><img name="layout_r7_c10" src="images/layout_r7_c10.jpg" width="9" height="102" border="0" alt=""></td>
			  </tr>
			</table></td>
		  </tr>
		  <tr>
		   <td><img name="layout_r8_c6" src="images/layout_r8_c6.jpg" width="306" height="15" border="0" alt=""></td>
		  </tr>
		</table>
       <p></td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="454" height="18" border="0" alt=""></td>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c6.jpg" width="306" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
  <tr>
   <td>
   <table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td align="center" valign="top" background="images/box.jpg" height="200" width="380"><span class="style1">Product Inspection</span><br>
	     <br>
	    <img src="images/sevimg06.jpg" name="layout_r9_c1"  border="0" alt=""><br><br>
With decreasing product life cycle and time-to-market, the challenge to deliver quality products on-time is critical.
Inspections throughout the various stages of production can help you  monitor that quality requirements for the product are being met and support  on-time delivery of quality products.more...</td>
	   <td align="center"  valign="top" background="images/box.jpg" height="200" width="380"><span class="style1">Laboratory Testing</span><br><br>
	   <img name="layout_r9_c6" src="images/sevimg07.jpg"  border="0" alt=""><br><br>
Quark laboratories have advanced testing facilities, and have professional engineers to offer all-around and comprehensive products testing services. We help you set, meet, maintain and evolve quality, safety, and performance standards for your product lines, operations and supply chains.</td>
	  </tr>
	  <tr>
	   <td align="center" valign="top" background="images/box.jpg" height="200" width="380"><p><span class="style1">Factory Audit</span><br>
	         <br>
	         <img name="layout_r9_c6" src="images/sevimg04.jpg"  border="0" alt=""><br>
	     <br>It is a comprehensive way to know supplier�s abilities in many parts, give you a good picture of the supplier. Based on the ISO 9000 standard, our audits provide insights of a factory's operational and quality control system for your review before order is placed.
</td>
	   <td align="center" valign="top" background="images/box.jpg" height="200" width="380"><span class="style1">Compliance Certification</span><br>
	     <br>
	   <img name="layout_r9_c6" src="images/sevimg05.jpg"  border="0" alt=""><br><br>
Quark Technologies has been granted multiple accreditations from leading global approval agencies throughout the world, including FCC, CE, IEC, UL, SCS, Intertek, and TUV. We help our customer to minimise the adverse health and environmental impact of their products and processes for the benefit of society.</td>
	  
	  </tr>
	</table>
   </td>
  </tr>
  <tr><td><br></td></tr>

   <?php include("bottom.php") ?>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>


</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</div>
</body>
</html>