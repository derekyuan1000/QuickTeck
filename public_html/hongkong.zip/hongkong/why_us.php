<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">
.style1 {
				text-align: center;
				font-size: x-large;
				color: #FFFFFF;
				 font-weight:bold;

}

.style2 {
 text-align:center;
 font-size:20px;
	border: 3px solid #FFFFCC;
}

</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
  <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	      <td width="100%" valign="top"><img name="layout_r9_c1" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt="">
	        <table width="100%" border="0" cellspacing="4" cellpadding="4">
	         <tr>
  <td  colspan="2" bgcolor="FFA500" class="style1" width="100%" height="40">
<strong>Why Us</strong></td>
</tr>
<tr><td  colspan="2" width="100%" height="40"><br>
<font size="4">We have a team of well-experienced professionals and technicians of electronic produts testing, inspection and certification, and have a high efficiency management system. Through the good cooperation of the whole staff, our prompt operation cycle can help you to insure the shipment on schedule.<br>
Quark provides comprehensive testing, inspection and certification services which cover all ranges of electronic market and product standards in the world. Quark provides a chain service of production process to meet all your demands. <br>
Our honest, impartial and professional inspection service can lower your risk of receiving defective goods.<br>
We will ensure that your commodities are compliant with the mandatory and non-mandatory safety regulations.<br>
Good testing equipment and after-sales service guarantee your confidence. <br>
Consistent in providing customer-centered service and flexible operations will win more time and space for you.<br>
Reduce your business trip expenses and other miscellaneous expenses resulted from goods inspections if carried out by yourself.  </font></td></tr>
            </table></td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>

 <?php include("bottom.php") ?>

  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>