<html>
<head>
<title>Quark Technologies Hong Kong Ltd</title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="description" content="FW MX FP HTML">

<script language="JavaScript">
<!-- hide this script from non-javascript-enabled browsers

// stop hiding -->
</script>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<style type="text/css">

.style1 {
				text-align: center;
				font-size: x-large;
				color: #FFFFFF;
				 font-weight:bold;

}
.style2 {
 text-align:center;
 font-size:20px;
	border: 3px solid #FFFFCC;
}
.style3 {
				font-size:15px;
				text-align: left;
}
.style4 {
				
				font-size:20px;
				font-family: Verdana;
				font-weight: bold;
				color: #FF6600;
}

</style>

<body bgcolor="#ffffff" leftmargin="0" topmargin="0" rightmargin="0" onLoad="">
<table border="0" cellpadding="0" cellspacing="0" width="760">
  <tr>
   <td>
  <?php include("main.php") ?>
   </td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
<tr>
  <td  colspan="2" bgcolor="FFA500" class="style1" width="100%" height="40">
<strong>Porduct Inspections</strong></td>
</tr>
 <tr>
 <td height="220" width="413" style="line-height:25px">
	
<p class="MsoNormal">
<font face="verdana, geneva" size="small" class="Apple-style-span">
<img alt="Quark,PCB manufacture" src="/images/mark1.gif" width="12" height="12" > We inspect all types of consumer and industrial products, raw materials and partially finished goods on-site at the factory BEFORE they ship out.<br>
<img alt="Quark,UK PCB manufacture" src="/images/mark1.gif" width="12" height="12" > Expert local inspection teams perform inspections based on internationally recognized ASQ/ANSI standards<br>
<img alt="Quark,UK PCB manufacturer" src="/images/mark1.gif" width="12" height="12" > Detailed reports with photos are available shortly after the inspection and Quark Technologies staff will assist you when there are quality issues<br>

</font></p>

 
</td><td width="347" class="style31">
<img alt="Quark PCB manufacture,component sourcing" src="images/inpspecitonpage1.jpg" width="347" height="346" />

</td>
</tr>
<tr>
  <td  colspan="2" width="100%" height="40">
<span class="style4">Pre-Production Inspection</span><br>
<span class="style3"><br>
Pre-Production Inspection were taken when only the first 0-20% of the production has been completed. This allows for immediate insight into the actual capacity and preparation level at the factory, and potential production issues while these is still time to adjust. we ensures that necessary corrective actions are well understood by the factory and will be implemented in the earlier phase.<br>
Quark inspection team check the status of raw materials, packaging materials, components, and the initial finished goods.  We provide you important information from the factory floor including the true production timeline, factory�s real production capacity and what in the production process is causing quality issues.<br>
</span><br>
<br>

<span class="style4">During Production Inspection</span><br>
<span class="style3"><br>
The most effective way of preventing last minute quality related delays is by inspecting and monitoring the product early in the manufacturing process. By initiating a rigorous inspection weeks or even months before your shipment is due, we can ensure that the quality and timely delivery of your merchandise is never in jeopardy. During Production Inspection not only check the initial products coming off the product line, but also check and document the status of raw materials, components, and partially finished goods.<br>
<br>

You will receive a report containing information about production flow, equipment use, production capacity, and any potential issues or bottlenecks. After reviewing the findings with you, we will help you take any necessary corrective or preventative actions, ensuring that next-steps are understood and implemented by factory management.</span><br>
<br>

<span class="style4">Random Inspection</span><br>
<span class="style3"><br>
Any manufacturer can produce a perfect sample. But can they also guarantee the quality of an entire batch? Quark expert team can visit the factory without notice (agreed in the contract), randomly pick up the samples from the product line and verify whether they were manufactured according to specifications and checking whether they meet quality requirements.</span><br>
<br>

<span class="style4">Pre-Shipment Inspection</span><br>
<span class="style3"><br>
A Final Pre-Shipment Inspection lets you rest assured that the goods you�re receiving are of excellent quality and that you will not need to re-inspect or deal with quality issues once they reach their destination. Quark  China based expert team are dispatched to the factory and inspect your merchandise based on internationally recognized AQL standards. Goods are reviewed rigorously on-site through a variety of industry standard tests and measurements to ensure that the material, performance, function, and overall quality meet your specifications.<br><br>

Final Pre-Shipment Inspections generally take place when 80 � 100% of the goods have been completed by the factory, just prior to shipment. Within 24 hours of our inspection, you will receive a full inspection report with photos/videos, giving you an in-depth look at the product, packaging, and testing performed. At every step in the process, Our English speaking team are standing by to answer your questions and get involved at the factory on your behalf to help deal with any quality or production issues.</span><br><br><br>

</td></tr>


	</table>
	</td>
  </tr>
  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r9_c6" src="images/layout_r9_c1.jpg" width="760" height="18" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>

 <?php include("bottom.php") ?>

  <tr>
   <td><table border="0" cellpadding="0" cellspacing="0" width="760">
	  <tr>
	   <td><img name="layout_r11_c1" src="images/layout_r11_c1.jpg" width="454" height="12" border="0" alt=""></td>
	   <td><img name="layout_r11_c6" src="images/layout_r11_c6.jpg" width="306" height="12" border="0" alt=""></td>
	  </tr>
	</table></td>
  </tr>
</table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>