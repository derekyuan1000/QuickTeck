﻿<html>
<head><title>PHP Mail Sender</title></head>
<body>
<?php 
$to = "pcb_prototype@hotmail.co.uk,info@quick-teck.co.uk" ; 
$from = $_REQUEST['Email'] ; 
$name = $_REQUEST['Name'] ; 
$headers = "From: $from"; 
$subject = "Customer contact form"; 

$fields = array(); 
$fields{"Name"} = "Name"; 
$fields{"Company"} = "Company"; 
$fields{"Email"} = "Email"; 
$fields{"Phone"} = "Phone"; 
$fields{"Message"} = "Message"; 

$body = "We have received the following information:\n\n"; foreach($fields as $a => $b){ $body .= sprintf("%20s: %s\n",$b,$_REQUEST[$a]); } 

$headers2 = "From: info@quick-teck.co.uk"; 
$subject2 = "Thank you for contacting us"; 
$autoreply = "Thank you for contacting us. We will contact you as soon as possible, normally within 12 hours. If you have any more questions, please consult our website at www.quick-teck.co.uk";

if($from == '') {print "You have not entered an email, please go back and try again";} 
else { 
if($name == '') {print "You have not entered a name, please go back and try again";} 
else { 
$send = mail($to, $subject, $body, $headers); 
/*$send2 = mail($from, $subject2, $autoreply, $headers2); */
if($send) 

{
print "<br />"; 
print "<br />"; 
print "<br />"; 
print " Hi $name, <br/><br/>
Thanks for your information. We will contact you shortly. "; 
print "<br />"; 
print "<br />"; 
print "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp;
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;Quick-teck "; 
}

else 
{
print "<br />"; 
print "<br />"; 
print "<br />"; 
print " We encountered an error sending your mail, please notify info@quick-teck.co.uk"; 
print "<br />"; 
print "<br />"; 
print "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
 &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; Quick-teck "; 
} 
}
}
?> </body>
</html> 
