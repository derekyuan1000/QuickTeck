<?php

// grab recaptcha library
require_once "recaptchalib.php";

// your secret key
$secret = "6LeEUpQUAAAAABhU14YeCdRB_3SgNaq8mGABg2wS";

// empty response
$response = null;

// check our secret key
$reCaptcha = new ReCaptcha($secret);

// if submitted check response
if ($_POST["g-recaptcha-response"]) {
    $response = $reCaptcha->verifyResponse(
        $_SERVER["REMOTE_ADDR"],
        $_POST["g-recaptcha-response"]
    );
}

?>

<?php
      if (!$response->success)
	   {
        echo "Hi just tick the box if you are not a robot!";
      } else { 
    ?>

<?php
session_start();
$authnum = $_SESSION['authnum'];
$checkString = trim($_POST['checkString']);
$from = $_REQUEST["Email"] ; 
$name = $_REQUEST["Name"] ; 
$company = $_REQUEST["Company"]; 
$email = $_REQUEST["Email"]; 
$phone = $_REQUEST["Phone"];
$componentsIssue = $_REQUEST["ComponentsIssue"]; 
$message = $_REQUEST["Message"]; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Low Cost PCB Manufacturer, Online Quote, UK PCB Manufacturer, Prototype manufacturer</title>
<meta name="description" content="Low Cost PCB Manufacturer, Online Quote, pcb manufacturer, UK PCB Prototype Fabrication offering 6pcs two layers prototype to 10pcs one layer PTH prototype." />
<meta name="keywords" content="Low Cost PCB Manufacturer, Online Quote, pcb manufacturer, UK PCB Prototype Manufacturer,pcbs,PCB Prototype Fabrication, Fabrication,10pcs two layers prototype, 10pcs two layers prototype, 8pcs two layers prototype" />
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link href="/rescources/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/rescources/js/jquery.min.js"></script>
<script src="/rescources/js/ainatec.js" type="text/javascript"></script>
</head>
<body class="bg">
<?php include '../static/header.php';
	if($authnum != strtoupper($checkString)){
		$errorClient = new Client(0, "", "", "", $name, "", "", $phone, $email, "", "", 0, 0, $message,
			"", "", "", "", "", $company);
		$_SESSION['errorClient'] = $errorClient;
		$_SESSION['message'] = "<span style='color:red;'>Invalid verification code</span>";
		echo "<script type='text/javascript'>history.back();</script>";
		return;
	}else{
		unset($_SESSION['authnum']);
	}
	$to = "pcb_prototype@hotmail.co.uk,info@quick-teck.co.uk" ; 
	$headers = "From: $from";  
	$subject = "Contact Us Form"; 
	$fields = array(); 
	$fields{"Name"} = "Name"; 
	$fields{"Company"} = "Company"; 
	$fields{"Email"} = "Email"; 
	$fields{"Phone"} = "Phone";
	$fields{"ComponentsIssue"} = "ComponentsIssue"; 
	$fields{"Message"} = "Message"; 
	$body = "Contact us form:\n\n"; foreach($fields as $a => $b){ $body .= sprintf("%20s: %s\n",$b,$_REQUEST[$a]); } 
	$headers2 = "From: info@quick-teck.co.uk"; 
	$subject2 = "Thank you for contacting us"; 
	$autoreply = "Thank you for contacting us. We will contact you as soon as possible, normally within 12 hours. If you have any more questions, please consult our website at www.quick-teck.co.uk";
?>
<div class="w980 auto clearbox mt5">
		<div class="w980 banner"><a href="#" title=""><img src="/rescources/images/banner02.jpg" width="980" height="170" alt="" /></a></div>
		<div class="bnav ico_home mt10"><a href="#" title="">Home</a> - <a href="#" title="">Online quote</a> - <a href="#" title="">Manufacture Quote</a></div>
		<div class="fl mt10 left_box">
			<div class="left_box_t"></div>
			<div class="left_box_c">
				<div class="mt10">
					<a href="#" title=""><img src="/rescources/images/paypal.jpg" width="233" height="75" alt="" class="ml10" /></a>
					<a href="#" title=""><img src="/rescources/images/opb.jpg" width="233" height="75" alt="" class="ml10 mt10" /></a>
					<p class="mt10 ml10">&nbsp;&nbsp;&nbsp;<span class="fs14 c_333">Follow Us On</span>&nbsp;&nbsp;&nbsp;<img src="/rescources/images/img1.gif" width="30" height="30" alt="" />&nbsp;&nbsp;&nbsp;<img src="/rescources/images/img2.gif" width="30" height="30" alt="" /></p>
				</div>
			</div>
		<div class="left_box_b"></div>
			
		</div>

				<div class="w710 fr mt10">
							<div class="main_box clearbox">
							<img src="/rescources/images/em.png" width="46" height="46" alt="" class="nr_m10 fl" />
							<div class="right_box1 fr lh1.6em mt15">
								<span class="c_f30 ">&nbsp;&nbsp;&nbsp;&nbsp;
								<?php 
								if($from=='') {echo 'You have not entered an email, please go back and <a href="javascript:history.go(-1)">try again</a>.';}
								else if($name=='') {echo 'You have not entered a name, please go back and <a href="javascript:history.go(-1)">try again</a>.';}
								else {$send = mail($to, $subject, $body, $headers);
								if($send) { echo 'Hi '.$name.',<br/><br/>Thanks for your information. We will contact you shortly.';}
								else {echo 'Hi '.$name.', <br/><br/>We encountered an error sending your mail, please notify info@quick-teck.co.uk and we will come back to you very soon.';}
								}
								?>
								
</span>
								</p>
							</div>
							<div class="clear"></div>
						</div>
				</div>
	<div class="clear"></div>
</div>
<?php include '../static/footer.php'?>
</body>
</html>
<?php } ?>