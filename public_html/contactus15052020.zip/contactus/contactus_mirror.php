<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Low Cost PCB Manufacturer,UK PCB Manufacturer, print circuit board manufacture,Prototype manufacturer</title>
<meta name="description" content="Contact Quick-teck quality and service as a UK PCB manufacturer, offering prototypes to volume production PCBs at low price." />
<meta name="keywords" content="Contact Quick-teck quality and service as a UK PCB manufacturer, offering prototypes to volume production PCBs at low price." />
<meta content="text/html; charset=ISO-8859-1" http-equiv="Content-Type" /><!--CharSet-->
<link rel="stylesheet" type="text/css" href="../../images/CSS.CSS" />
<script type="text/javascript" src="../Management/Scripts/jquery-1.4.2.js"></script>
<script type="text/javascript">
	var jq = jQuery.noConflict();
	jq(document).ready(function() {
		jq(".h2_cat").mousemove(function() {
			jq(this).addClass("h2_cat active_cat");
		}).mouseout(function() {
			jq(this).removeClass("active_cat");
		});
	});
</script>
<link href="../Management/Styles/menu.css" type="text/css" rel="Stylesheet" />


<style type="text/css"><!--

.style34 {
				text-align: center;
				 background:gray;
				font-size: large;
				color: #FFFFFF;
}

.style35 {
				font-size: small;
}

.style36 {
				font-weight: bold;
				font-size: medium;
				background:#CCCCCC;	
					
				
}

--></style>
<script id="clientEventHandlersJS" language="javascript">
<!--

function window_onload() {
<!--Page.OnLoad-->
}

function openwindow(url,name,iWidth,iHeight)
{
var url;
var name;
var iWidth;
var iHeight;
var iTop = (window.screen.availHeight-30-iHeight)/2;
var iLeft = (window.screen.availWidth-10-iWidth)/2;
window.open(url,name,'height='+iHeight+',,innerHeight='+iHeight+',width='+iWidth+',innerWidth='+iWidth+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars=auto,resizeable=no,location=no,status=no');
}

//-->
</script>
<!--
<script src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js" type="text/javascript"></script>
-->
<script type="text/javascript">
function $(id){
	return document.getElementById(id);
}
function closeDiv(){
	$("mscroll").style.display = "none";
}
function move(){
	$("mscroll").style.pixelTop = document.body.scrollTop + 5;
}
//window.onscroll=move;
</script>
</head>
<body bgcolor="#cccc99" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" language="javascript" onload="return window_onload()">
<!--Counter-->
<!--<?php include("../comment/message_flag.php") ?>-->
<!--Something Here-->
<?php include("../Management/Client/topper.php") ?>

<table width="778" border="0" cellspacing="0" cellpadding="0" align="center" background="../../images/index_bg.gif">
<tr>
<td width="214" valign="top">
<table width="214" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="top"> <br />
<?php include("../Management/Client/menu.php") ?>

	</td></tr>
</table></td>
<td valign="top">
<table border="0" cellspacing="0" cellpadding="0" align="center" style="width: 524px; height: 417px">
<tr valign="top">
<td> <!--IndexPage.Content.Begin-->
<?php include("../Management/Client/row1.php") ?>
</td></tr>

<tr><td style="height: 227px">
<!--<form method="post" target="aa" onsubmit="openwindow('','aa',350,350)" action="contactform.php">-->
<form method="post" action="contactform2.php">
<table style="width: 100%; height: 355px" bgcolor="#ffffcc" align="center">
<tbody>
<tr>
<td class="style34" colspan="2"><strong><span class="style36"></span>Contact Form</strong> </td></tr>
<tr>
<td style="width: 63px"><font color="red">*</font> <span class="style35">Name:</span></td>
<td><input style="width: 137px" size="25" name="Name" /></td></tr>
<tr>
<td style="width: 63px; height: 25px"><font color="red">*</font> <span class="style35">Email:</span></td>
<td style="height: 25px"><input style="width: 137px" size="25" name="Email" /></td></tr>
<tr>
<td style="width: 63px"><span class="style35">Company:</span></td>
<td><input style="width: 137px" size="25" name="Company" /></td></tr>
<tr>
<td style="width: 63px"><span class="style35">Phone:</span></td>
<td><input style="width: 137px" size="25" name="Phone" /></td></tr>
<tr>
<td colspan="2"><span class="style35">Message:</span></td></tr>
<tr>
<td style="width: 63px"></td>
<td><textarea rows="5" cols="48" name="Message"></textarea></td></tr>
<tr>
<td style="height: 40px" colspan="2" align="center"><input style="width: 79px" class="style36" value="Submit" type="submit" name="send" /></td></tr>
<tr>
<td colspan="2" align="center"><small>A <font color="red">*</font> indicates a field is required</small></td></tr></tbody></table>
<hr /><br />
</form>
</td></tr>

<!--IndexPage.Content.End-->
<tr><td>
    <table width="94%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
               <td><br>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" class="englishfont" height="1">
                   <tr> 
                     <td bgcolor="#000000"> </td>
                   </tr>
                 </table>
                 <br>
               </td>
         </tr>
    </table>
</td></tr>
<tr>
 <td>
<div style="width: 458px; height: 80px" align="center">
<p><!--Your Company Name-->
Quick-teck �2009-2012<br>
<!--TAddress--><!--TTelephone-->E: info@quick-teck.co.uk <br />
T: 01462-456230,  F: 01462-887598<br/>
VAT Reg No: 114535342<br>24 Meadow bank, Hitchin, Hertfordshire, SG4 0HY,UK </div></td></tr></table><br>
</td></tr></table>
<table border="0" cellspacing="0" cellpadding="0" width="778" align="center">
<tbody>
<tr>
<td><img alt="" src="../../images/index_bottom.gif" /></td></tr></tbody></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12471272-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>