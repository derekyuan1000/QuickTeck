<?php
session_start();
include_once($_SERVER['DOCUMENT_ROOT']."/Management/DAL/EEAttributeValueService_Class.php");
include_once($_SERVER['DOCUMENT_ROOT']."/Management/Models/Client_Class.php");
$langdate['contactus'][0]['english']='Home';
$langdate['contactus'][0]['french']='Accueil';
$langdate['contactus'][0]['dutch']='';
$langdate['contactus'][0]['spanish']='';
$langdate['contactus'][1]['english']='Contact us';
$langdate['contactus'][1]['french']='Contacts';
$langdate['contactus'][1]['dutch']='';
$langdate['contactus'][1]['spanish']='';
$langdate['contactus'][2]['english']='Contact form';
$langdate['contactus'][2]['french']='Formulaire de contact';
$langdate['contactus'][2]['dutch']='';
$langdate['contactus'][2]['spanish']='';
$langdate['contactus'][3]['english']='Testimonial';
$langdate['contactus'][3]['french']='Témoignage';
$langdate['contactus'][3]['dutch']='';
$langdate['contactus'][3]['spanish']='';
$langdate['contactus'][4]['english']='Contact Form ';
$langdate['contactus'][4]['french']='Formulaire de contact';
$langdate['contactus'][4]['dutch']='';
$langdate['contactus'][4]['spanish']='';
$langdate['contactus'][5]['english']='A indicates field is required';
$langdate['contactus'][5]['french']='Champs obligatoires';
$langdate['contactus'][5]['dutch']='';
$langdate['contactus'][5]['spanish']='';
$langdate['contactus'][6]['english']='Name';
$langdate['contactus'][6]['french']='Nom';
$langdate['contactus'][6]['dutch']='';
$langdate['contactus'][6]['spanish']='';
$langdate['contactus'][7]['english']='Email';
$langdate['contactus'][7]['french']='Courriel';
$langdate['contactus'][7]['dutch']='';
$langdate['contactus'][7]['spanish']='';
$langdate['contactus'][8]['english']='Company';
$langdate['contactus'][8]['french']='Entreprise';
$langdate['contactus'][8]['dutch']='';
$langdate['contactus'][8]['spanish']='';
$langdate['contactus'][9]['english']='Phone';
$langdate['contactus'][9]['french']='Téléphone';
$langdate['contactus'][9]['dutch']='';
$langdate['contactus'][9]['spanish']='';
$langdate['contactus'][10]['english']='Message';
$langdate['contactus'][10]['french']='Message';
$langdate['contactus'][10]['dutch']='';
$langdate['contactus'][10]['spanish']='';
$langdate['contactus'][11]['english']='/rescources/images/banner02.jpg';
$langdate['contactus'][11]['french']='/rescources/images/banner02_fr.jpg';
$langdate['contactus'][11]['dutch']='';
$langdate['contactus'][11]['spanish']='';
$langdate['contactus'][12]['english']='Submit';
$langdate['contactus'][12]['french']='Soumettre';
$langdate['contactus'][12]['dutch']='';
$langdate['contactus'][12]['spanish']='';
$langdate['contactus'][13]['english']='Follow Us On';
$langdate['contactus'][13]['french']='Suivez-Nous Sur';
$langdate['contactus'][13]['dutch']='';
$langdate['contactus'][13]['spanish']='';
$langdate['contactus'][14]['english']='visibility:hidden;';
$langdate['contactus'][14]['french']='';
$langdate['contactus'][14]['dutch']='';
$langdate['contactus'][14]['spanish']='';
$langdate['contactus'][15]['english']='Verification code';
$langdate['contactus'][15]['french']='Code de vérification';
$langdate['contactus'][15]['dutch']='';
$langdate['contactus'][15]['spanish']='';
$langdate['contactus'][16]['english']='Try a different image';
$langdate['contactus'][16]['french']='Essayer une autre image';
$langdate['contactus'][16]['dutch']='';
$langdate['contactus'][16]['spanish']='';

$eeId = !empty($_GET['eeId'])?$_GET['eeId']:"";
$type = !empty($_GET['type'])?$_GET['type']:"";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Low Cost PCB Manufacturer,UK PCB Manufacturer, printed circuit board manufacture,Prototype manufacturer</title>
<meta name="description" content="Contact Quick-teck quality and service as UK Printed circuit board manufacturer, offering prototypes to volume production PCBs at low price." />
<meta name="keywords" content="Contact Quick-teck quality and service as UK PCB manufacturer, offering prototypes to volume production PCBs at low price." />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><!--CharSet-->
<link href="/rescources/css/style.css" rel="stylesheet" type="text/css" />
<link href="/rescources/widget/css/rcarousel.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="/rescources/js/jquery.min.js"></script>
<script src="/rescources/js/ainatec.js" type="text/javascript"></script>
<script type="text/javascript" src="/rescources/widget/lib/jquery.ui.core.min.js"></script>
<script type="text/javascript" src="/rescources/widget/lib/jquery.ui.widget.min.js"></script>
<script type="text/javascript" src="/rescources/widget/lib/jquery.ui.rcarousel.min.js"></script>
<script type="text/javascript" src="/rescources/widget/lib/jammy.js"></script>
<script type="text/javascript">
function getNewPic() {
		$("#checkPic").attr("src",$("#checkPic").attr("src")+"?"+Math.random());
};
</script>
</head>
<body class="bg">
<?php include '../static/header.php';?>
<div class="w980 auto clearbox mt5">
		<?php include '../static/carousel.php';?>
		<div class="bnav ico_home mt10"><a href="/" title=""><?php Lang::EchoString2($langdate['contactus'][0]);?></a> - <a href="#" title=""><?php Lang::EchoString2($langdate['contactus'][1]);?></a></div>
		<div class="fl mt10 left_box">
			<div class="left_nav_title"> <span class="ico_title"><?php Lang::EchoString2($langdate['contactus'][1]);?></span> </div>
			<div class="left_box_c">
				<div class="left_nav">
					<ul>
						<li><a href="/contactus/contactus.php" title="" class="on"><?php Lang::EchoString2($langdate['contactus'][2]);?></a></li>
						<li><a href="/contactus/testimonial/index.php" title=""><?php Lang::EchoString2($langdate['contactus'][3]);?></a></li>
					</ul>
				</div>
				<div class="mt10">
					<a href="/contactus/testimonial/index.php" title=""><img src="/rescources/images/03.gif" width="233" height="75" alt="" class="ml10" style="margin-top:10px;"/></a>
					<a href="/onlinequote/onlinequote.php" title=""><img src="/rescources/leftpic/05.gif" width="233" height="75" alt="" class="ml10" style="margin-top:10px;"/></a>
					<a href="/FAQ/FAQ.php#Shipping_001" title=""><img src="/rescources/images/02.gif" width="233" height="75" alt="" class="ml10" style="margin-top:10px;"/></a>
					<a href="/News/Atrcles.php" title=""><img src="/rescources/leftpic/08.gif" width="233" height="75" alt="" class="ml10" style="margin-top:10px;"/></a>
					<p class="mt10 ml10">&nbsp;&nbsp;&nbsp;<span class="fs14 c_333"><?php Lang::EchoString2($langdate['contactus'][13]);?></span>&nbsp;&nbsp;&nbsp;<a href="http://twitter.com/quickteck" target="_blank"><img src="/rescources/images/img1.gif" width="30" height="30" alt="" /></a>&nbsp;&nbsp;&nbsp;<a href="http://www.facebook.com/quickteck"  target="_blank"><img src="/rescources/images/img2.gif" width="30" height="30" alt="" /></a></p>
				</div>
			</div>
		<div class="left_box_b"></div>
			
		</div>

				<div class="w710 fr mt10">
				<form method="post" action="contactform2.php">
					<h3 class="title_main"><?php Lang::EchoString2($langdate['contactus'][4]);?></h3>
					<div class="online_from mt10">
						<p> <span class="c_f30 lh2em">*</span><?php Lang::EchoString2($langdate['contactus'][5]);?></p>
					<table width="100%" border="0" cellspacing="0" cellpadding="0"  >
					  <tr>
						<td width="168" class="w_168"><span class="c_f30">*</span><?php Lang::EchoString2($langdate['contactus'][6]);?>:</td>
						<td><input style="width: 137px" size="25" name="Name" value="<?php echo $_SESSION['errorClient']->Name ?>"/></td>
					  </tr>
					  <tr>
						<td class="w_168"><span class="c_f30">*</span> <?php Lang::EchoString2($langdate['contactus'][7]);?>:</td>
						<td><input style="width: 137px" size="25" name="Email" value="<?php echo $_SESSION['errorClient']->Email ?>"/></td>
					  </tr>
					  <tr>
						<td class="w_168"><?php Lang::EchoString2($langdate['contactus'][8]);?>:</td>
						<td><input style="width: 137px" size="25" name="Company" value="<?php echo $_SESSION['errorClient']->Company ?>"/></td>
					  </tr>
					  <tr>
						<td class="w_168"><?php Lang::EchoString2($langdate['contactus'][9]);?>:</td>
						<td><input style="width: 137px" size="25" name="Phone" value="<?php echo $_SESSION['errorClient']->Telephone ?>"/></td>
					  </tr>
					  <tr>
					   <td class="w_168">
							<?php Lang::EchoString2($langdate['contactus'][10]);?>:
					</td>
						<td>
							<?php
							if($eeId && $type == "eeIssues"){
								$eeAttributeValueService = new EEAttributeValueService();
								$attributeValueArray = $eeAttributeValueService->GetEEAttributeValueByEEId($eeId);
								$attributeValue = $attributeValueArray[78];
								$name = $attributeValue->AttributeValue;
								$attributeValue = $attributeValueArray[5];
								$orderCode = $attributeValue->AttributeValue;
								$titleMessage = 'I would like to draw your attention that '.$orderCode.' ('.$name.') looks like have prices/description issues. Details are as below: ';
								$titleMessage1 = '<p style="margin-bottom:5px">'.$titleMessage.'</p>';
								echo $titleMessage1;
								echo '<input type="hidden" value="'.$titleMessage.'" id="ComponentsIssue" name="ComponentsIssue"/>';
							}
							?>
							<textarea class="text1" name="Message"><?php echo $_SESSION['errorClient']->Remark ?></textarea>
						</td>
					  </tr>
					  <tr>
					   <td><?php Lang::EchoString2($langdate['contactus'][15]);?>:</td>
						<td colspan="3"><input id="checkString" name="checkString" type="text" class="myInput"/>
						&nbsp;<img id="checkPic" src="../clients/createCheckPic_client.php" alt="" style="margin-top:5px;vertical-align:bottom"/>
						&nbsp;<a id="getCheckPic" href="#" style="color:#005AA0" onclick="getNewPic();"><?php Lang::EchoString2($langdate['contactus'][16]);?>.</a></td>
					  </tr>
					</table>
<?php 
if($_SESSION["message"]){
	$temp = $_SESSION["message"]; 
	$temp = str_replace("<span style='color:red;'>","",$temp);
	$temp = str_replace("</span>","",$temp);
	$temp = str_replace("<br/>","",$temp);
	echo '<script>alert(\''.$temp.'\');</script>';
}
unset($_SESSION["errorClient"]); 
echo $_SESSION["message"]; 
$_SESSION["message"]=""; 
				?>
					<p class="mt10 tc"><input type="submit" value="<?php Lang::EchoString2($langdate['contactus'][12]);?>" class="submit_bn"  name="send" /></p>
					<table width="100%" border="0" cellspacing="0" cellpadding="0"  style="margin-top:60px;display:none;" border="0">
					  <tr>
						<td width="168" class="w_168">Contact address:</td>
						<td>
						 Unit 7, The Quadrant
						 Newark Close, Royston, UK
						 SG8 5HL
						</td>
					  </tr>
					  <tr>
						<td class="w_168">Email: </td>
						<td>info@quick-teck.co.uk</td>
					  </tr>
						<tr>
						<td class="w_168">Tel: </td>
						<td>01763-448118</td>
					  </tr>
					  <tr>
						<td class="w_168">Fax: </td>
						<td>01763-802102</td>
					  </tr>
					   <tr>
						<td class="w_168">UK VAT No:  </td>
						<td>114535342</td>
					  </tr>
					</table>
					<div style="background:#F9F9F9;border:1px solid #F30;margin-top:20px;padding:20px;height:80px;">
					<p style="float:left;width:190px;">
					Contact address:<br />
					     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quick-teck Electronics Ltd<br />
						 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Unit 7, The Quadrant<br />
				         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Newark Close, Royston, UK<br />
				         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SG8 5HL<br />
						 <br/>
					</p>
				    <p style="float:right;margin-right:180px;width:220px;">
				       Email:  <a href="mailto:info@quick-teck.co.uk">info@quick-teck.co.uk</a><br />
				       Tel: 01763-448118<br />
				       Fax: 01763-802102<br />
				       UK VAT No:114535342<br />
					   UK Company No:09615552<br />
				    </p>
					</div>
					<div style="background:#F9F9F9;border:1px solid #ccc;margin-top:10px;padding:3px 5px 5px 3px;height:75px; <?php Lang::EchoString2($langdate['contactus'][14]);?>">
					<p style="width:95%;">
					Devenez notre représentant:<br>
<br>
Vous souhaiteriez nous aider à développer la distribution de notre industrie dans votre pays? Quick-Teck sers ses clients en Europe directement. Toutefois, nous souhaiterions étendre nos services dans chaque Pays. Si vous souhaitez d'autres possibilités d'étendre votre activité, nous sommes prêt à discuter d'un contrat de représentation avec vous.
				    </p>
					</div>
				</div>
			</form>
		</div>
	<div class="clear"></div>
</div>
<?php include '../static/footer.php';?>
</body>
</html>