PCB 1016 4G Module Issue 2.0 Prototype
3/7/18

Top Layer1 Tracks Gerber

	Top_Layer.rep
	Top_Layer.pho

Inner2 Layer2 Tracks Gerber
	
	Inner2.rep
	Inner2.pho

Inner3 Layer3 Tracks Gerber
	
	Inner3.rep
	Inner3.pho

Bottom Layer4 Tracks Gerber
	
	Bot_layer.rep
	Bot_layer.pho


Top Layer Silk Screen Gerber

	Top_Silk.rep
	Top_Silk.pho


Top Layer Solder Mask Gerber

	Top_Solder_Mask.rep
	Top_Solder_Mask.pho


Bottom Layer Solder Mask Gerber
	
	Bot_Solder_Mask.rep
	Bot_Solder_Mask.pho


NC Dril File

	NCdrill.rep
	NCdrill.lst
	NCdrill.drl


Routing Gerber

	routings.rep
	routings.pho

PCB to be 4 Layer 1.6mm FR4 1Oz Copper See Assembly Drawing for PCB layer thicknesses
Standard Green Solder mask
Standard White Silk screen

Any Problems Email on greg.lane@gemmtech.com
